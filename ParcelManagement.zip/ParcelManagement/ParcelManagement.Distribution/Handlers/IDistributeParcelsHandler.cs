﻿using System;
namespace ParcelManagement.Distribution.Handlers
{
    public interface IDistributeParcelsHandler
    {
        void Handle();
    }
}
